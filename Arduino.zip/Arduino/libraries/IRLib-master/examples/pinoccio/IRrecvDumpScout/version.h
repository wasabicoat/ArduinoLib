#define SKETCH_NAME "IRrecvDumpScout"
#define SKETCH_BUILD 1.5
#define SKETCH_REVISION "1.5"
